package com.example.apipokemon;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class PokemonsViewModel extends AndroidViewModel {
    private final AppDatabase appDatabase;
    private final PokemonDao pokemonDao;
    private LiveData<List<Pokemon>> pokemons;

    public PokemonsViewModel(Application application) {
        super(application);

        this.appDatabase = AppDatabase.getDatabase(application);
        this.pokemonDao = appDatabase.getPokemonDao();
        this.pokemons = pokemonDao.getPokemons();
    }

    public LiveData<List<Pokemon>> getPokemons() {
        return pokemons;
    }

    public void reload() {
        RefreshDataTask task = new RefreshDataTask();
        task.execute();
    }

    private class RefreshDataTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            PokemonApi api = new PokemonApi();
            List<Pokemon> result = api.getPokemons();

            appDatabase.clearAllTables();
            pokemonDao.addPokemons(result);

            return null;
        }
    }
}