package com.example.apipokemon;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity
public class Pokemon implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private long id;
    private String name;
    private String weight;
    private String height;
    private String image;
    private String detailsUrl;

    public long getId() {return id;}
    public void setId(long id) {this.id = id;}

    public String getDetailsUrl() {
        return detailsUrl;
    }

    public void setDetailsUrl(String detailsUrl) {
        this.detailsUrl = detailsUrl;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    @Override
    public String toString() {
        return "Pokemon{" +
                "name='" + name + '\'' +
             //   ", weight=" + weight +
            //    ", height=" + height +
             //   ", image='" + image + '\'' +
                '}';
    }
}
