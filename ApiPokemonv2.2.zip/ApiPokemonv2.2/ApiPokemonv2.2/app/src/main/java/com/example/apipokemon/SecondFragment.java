package com.example.apipokemon;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.apipokemon.databinding.FragmentSecondBinding;
import com.squareup.picasso.Picasso;

import java.util.Locale;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();

        if (args != null) {
            Pokemon pokemon = (Pokemon) args.getSerializable("pokemona");
            if (pokemon != null) {
                binding.txtNamePokemon.setText(pokemon.getName().toUpperCase(Locale.ROOT));
                binding.txtNamePokemon2.setText("Height:" + pokemon.getHeight());
                binding.txtNamePokemon3.setText("Weight" + pokemon.getWeight());

                String imageUrl = pokemon.getImage();
                if (imageUrl != null && !imageUrl.isEmpty()) {
                    Picasso.get().load(imageUrl).into(binding.imgpokemonDetail);
                } else {
                    System.out.println("NO SE HA ENCONTRADO NINGUNA IMAGEN");
                }
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}